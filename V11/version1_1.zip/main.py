# -*- coding: utf-8 -*-
"""
Created on Thu Dec  2 20:49:37 2021

@author: 78528
"""

import pygame
import Game

def main():
    menu = Menu()
    menu.run()
    game = Game.Game()
    game.run()
    
    
    
if __name__ == '__main__':
    main()
