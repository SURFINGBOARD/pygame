# -*- coding: utf-8 -*-
"""
Created on Thu Dec  2 13:19:49 2021

@author: 78528
"""
import pygame
pygame.init()

# w, h = pygame.display.Info().current_w, pygame.display.Info().current_h*19/20
w, h = 500, 500